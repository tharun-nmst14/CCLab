public class Example{
    public static void main(String arg[]){
        System.out.println("hell Nagaraju");
    }
}