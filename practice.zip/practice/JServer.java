
import java.net.*;
import java.io.*;
public class JServer{
    public static void main(String a[]) throws Exception{
        ServerSocket ss=new ServerSocket(5004);
        System.out.println("Connection successful");
        System.out.println("Waiting for Client message");
        Socket s=ss.accept();
        DataInputStream din=new DataInputStream(s.getInputStream());  
         String line="";
          while (!line.equals("Over")) {
                    line = din.readUTF();
                    Runtime rt = Runtime.getRuntime();
                    if (!line.equals("Over")) {
                        Process p = rt.exec("javac " + line + ".java");
                        Process p2 = rt.exec("java " + line);
                        BufferedReader reader = new BufferedReader(new InputStreamReader(p2.getInputStream()));
                        String outputLine;
                        System.out.println("Dear client, your java program output is as follows:");
                        while ((outputLine = reader.readLine()) != null) {
                            System.out.println(outputLine);
                        }
                    }
}}}